import { Component, OnInit } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {

  title = 'Pipes| CRUD operation | Sorting Array';
  today = new Date();
  toggle = true;

  get format(){ return this.toggle ? 'shortDate' : 'fullDate'}
  toggleFormat() { this.toggle = !this.toggle;}

  time = new Observable<string>((s:Subscriber<string>)=>{
    setInterval(()=>s.next(new Date().toLocaleString()),1000);
  });

  constructor() { }

  ngOnInit() {
  }

}
