import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ourskill',
  templateUrl: './ourskill.component.html',
  styleUrls: ['./ourskill.component.css']
})
export class OurskillComponent implements OnInit {
  title = 'our skills';
  constructor() { }

  ngOnInit() {
  }

}
