import { DtabindingDirective } from './dtabinding.directive';

describe('DtabindingDirective', () => {
  it('should create an instance', () => {
    const directive = new DtabindingDirective();
    expect(directive).toBeTruthy();
  });
});
