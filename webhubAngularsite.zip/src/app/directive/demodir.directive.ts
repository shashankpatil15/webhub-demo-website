import { Directive } from '@angular/core';

@Directive({
  selector: '[appDemodir]'
})
export class DemodirDirective {

  constructor() { }

}
