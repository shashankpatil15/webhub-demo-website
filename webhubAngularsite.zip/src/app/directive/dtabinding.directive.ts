import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appDtabinding]'
})
export class DtabindingDirective {

  constructor(el: ElementRef) {
    el.nativeElement.style.backgroundColor = 'pink';
   }

}
