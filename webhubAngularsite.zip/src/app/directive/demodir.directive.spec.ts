import { DemodirDirective } from './demodir.directive';

describe('DemodirDirective', () => {
  it('should create an instance', () => {
    const directive = new DemodirDirective();
    expect(directive).toBeTruthy();
  });
});
