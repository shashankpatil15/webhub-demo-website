import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { FooterComponent } from './footer/footer.component';
import { ServicesComponent } from './services/services.component';
import { OurskillComponent } from './ourskill/ourskill.component';
import { WhychooseComponent } from './whychoose/whychoose.component';
import { TestimonialComponent } from './testimonial/testimonial.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { BlogComponent } from './blog/blog.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { PipesComponent } from './pipes/pipes.component';
import { AngularservicesComponent } from './angularservices/angularservices.component';
import { UsersComponent } from './users/users.component';

const routes: Routes= [
    {path:'home',component:HomeComponent},
    {path:'services',component:ServicesComponent},
    {path:'ourskill',component:OurskillComponent},
    {path:'whaychoose',component:WhychooseComponent},
    {path:'testimonial',component:TestimonialComponent},
    {path:'portfolio',component:PortfolioComponent},
    {path:'pipes',component:PipesComponent},
    {path:'login',component:LoginComponent},
    {path:'footer',component:FooterComponent},
    {path:'contactus',component:ContactusComponent},
    {path:'blog',component:BlogComponent},
    {path:'aboutus',component:AboutusComponent},
    {path:'register',component:RegisterComponent},
    {path:'pipes', component:PipesComponent},
    {path:'angularservices', component:AngularservicesComponent,
      children:[
        {path:'users', component:UsersComponent}
      ]
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes,{enableTracing:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
