import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angularservices',
  templateUrl: './angularservices.component.html',
  styleUrls: ['./angularservices.component.css']
})
export class AngularservicesComponent implements OnInit {

  title = 'webhub'; title1 = 'technology'
  constructor() { }

  ngOnInit() {
  }

}
