<!DOCTYPE html>
<html class="no-js" lang="en">
    <head>
		<meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="description" content="welcome to codeglim">
		<meta name='copyright' content='codeglim'>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">	
        <title>WebHUB Technology</title>
		<link rel="icon" type="image/png" href="images/favicon.png">	
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,700,900" rel="stylesheet"> 
		

		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC-eVSK_d3hPzECgAEvz6Dz0K8KpjYPG7w" type="text/javascript"></script>	
		
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/slicknav.min.css">
		<link rel="stylesheet" href="css/owl.theme.default.css">
        <link rel="stylesheet" href="css/owl.carousel.min.css">
		<link rel="stylesheet" href="css/magnific-popup.css">
		
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="css/default.css">	
        <link rel="stylesheet" href="css/responsive.css">	
		<link rel="stylesheet" href="css/skin/green.css">
		<![endif]-->
		<link rel="stylesheet" href="#" id="colors">
    </head>
    <body>
		<div class="loader">
			<div class="l-inner">
				<div class="k-spinner">
					<div class="k-bubble-1"></div>
					<div class="k-bubble-2"></div>
				</div>
			</div>
        </div>
		<div class="mp-color">
			<div class="icon inOut"><i class="fa fa-cog fa-spin"></i></div>
			<h4>Choose Color</h4>
			<span class="color1"></span>
			<span class="color2"></span>
			<span class="color3"></span>
			<span class="color4"></span>
			<span class="color5"></span>
			<span class="color6"></span>
			<span class="color7"></span>
			<span class="color8"></span>
		</div>
		<header id="header">
			<div class="container">
				<div class="row">
					<div class="col-md-2 col-sm-12 col-xs-12">
						<div class="logo">
							<a href="index.php"><span>WebHUB</span>Technology</a>
						</div>
					</div>
					<div class="col-md-8 col-sm-12 col-xs-12">
						<div class="nav-area">
							<!-- Main Menu -->
							<nav class="mainmenu">
								<div class="mobile-nav"></div>
								<div class="collapse navbar-collapse">
									<ul class="nav navbar-nav menu">
										<li class="active"><a href="#j-slider">Home</a></li>
										<li><a href="#about-us">About Us</a></li>
										<li><a href="#our-skill">Our Skill</a></li>
										<li><a href="#why-choose">Why Choose</a></li>
										<li><a href="#portfolio">Portfolio</a></li>		
										<li><a href="#blog">Blog</a></li>		
										<li><a href="#location">Contact</a></li>		
									</ul>
								</div>
							</nav>
						</div>
					</div>
					<div class="col-md-2">
						<ul class="social">
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li class="active"><a href="#"><i class="fa fa-linkedin"></i></a></li>
							<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</header>
		<section id="j-slider">
			<div class="slide-main">
				<!-- Single Slider -->
				<div class="single-slider" style="background-image:url(images/slider/slider-bg1.jpg);" >
					<div class="container">
						<div class="row">
							<div class="col-md-8 col-sm-12 col-xs-12">
								<!-- Slider Text -->
								<div class="slide-text left">
									<div class="slider-inner">
										<h1><span>we create</span>awesome business website</h1>
										<p>Lorem  ipsum dolor sit amet, ad mea evertitur voluptaria constituam, usu id graecis legendos mediocritatem, labitur iracundia vituperata eu hasPersequeris dissentiunt eam et. Offendit</p>
										<div class="slide-button">
											<a href="#" class="button primary">Contact Us</a>										</div>
									</div>
								</div>
								<!--/ End Slider Text -->
							</div>
						</div>
					</div>
				</div>
				<!--/ End Single Slider -->
				<!-- Single Slider -->
				<div class="single-slider" style="background-image:url(images/slider/slider-bg2.jpg);" >
					<div class="container">
						<div class="row">
							<div class="col-md-8 col-sm-12 col-xs-12">
								<!-- Slider Text -->
								<div class="slide-text left">
									<div class="slider-inner">
										<h1><span>we create</span>awesome business website</h1>
										<p>Lorem  ipsum dolor sit amet, ad mea evertitur voluptaria constituam, usu id graecis legendos mediocritatem, labitur iracundia vituperata eu hasPersequeris dissentiunt eam et. Offendit</p>
										<div class="slide-button">
											<a href="#" class="button primary">Contact Us</a>										</div>
									</div>
								</div>
								<!--/ End Slider Text -->
							</div>
						</div>
					</div>
				</div>
				<!--/ End Single Slider -->
				<!-- Single Slider -->
				<div class="single-slider" style="background-image:url(images/slider/slider-bg3.jpg);" >
					<div class="container">
						<div class="row">
							<div class="col-md-8 col-sm-12 col-xs-12">
								<!-- Slider Text -->
								<div class="slide-text left">
									<div class="slider-inner">
										<h1><span>we create</span>awesome business website</h1>
										<p>Lorem  ipsum dolor sit amet, ad mea evertitur voluptaria constituam, usu id graecis legendos mediocritatem, labitur iracundia vituperata eu hasPersequeris dissentiunt eam et. Offendit</p>
										<div class="slide-button">
											<a href="#" class="button primary">Contact Us</a>										</div>
									</div>
								</div>
								<!--/ End Slider Text -->
							</div>
						</div>
					</div>
				</div>
				<!--/ End Single Slider -->
			</div>
		</section>
		<!--/ End Slider -->
		
		<!-- Start Service -->
		<section id="service" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>Our <span>Service</span></h2>
							<p>Coordinates for abs potioning the closest positioned parent box of the positioned abs qoning the closes for abs potioning the closest positioned parent.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<!-- Single Service -->
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.4s">
						<div class="single-service">
							<i class="fa fa-check"></i>
							<h2>Web Design</h2>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy.</p>
						</div>
					</div>
					<!--/ End Single Service -->
					<!-- Single Service -->
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.6s">
						<div class="single-service">
							<i class="fa fa-edit"></i>
							<h2>Web Developments</h2>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy.</p>
						</div>
					</div>
					<!--/ End Single Service -->
					<!-- Single Service -->
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.8s">
						<div class="single-service">
							<i class="fa fa-send"></i>
							<h2>Smart Coding</h2>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy.</p>
						</div>
					</div>
					<!--/ End Single Service -->
					<!-- Single Service -->
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="1s">
						<div class="single-service">
							<i class="fa fa-code"></i>
							<h2>UI/UX Design</h2>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy.</p>
						</div>
					</div>
					<!--/ End Single Service -->
				</div>
			</div>
		</section>
		<!--/ End Service -->
		
		<!-- Start About Us -->
		<section id="about-us" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>About <span>US</span></h2>
							<p>Coordinates for abs potioning the closest positioned parent box of the positioned abs qoning the closes for abs potioning the closest positioned parent.</p>
						</div>
					</div>
				</div>
				<div class="row"> 
					<!-- About Image -->
					<div class="col-md-5 col-sm-12 col-xs-12 wow slideInLeft">
						<div class="about-main">
							<div class="about-img">
								<img src="images/about.jpg" alt=""/>
							</div>
						</div>
					</div>
					<!--/ End About Image -->
					<div class="col-md-7 col-sm-12 col-xs-12 wow fadeIn" data-wow-delay="1s">
						<!-- About Tab -->
						<div class="tabs-main">
							<!-- Tab Nav -->
							<ul class="nav nav-tabs" role="tablist">
								<li role="presentation" class="active"><a href="#welcome"  data-toggle="tab">Welcome</a></li>
								<li role="presentation"><a href="#about" data-toggle="tab">About Us</a></li>
								<li role="presentation"><a href="#information"  data-toggle="tab">Information</a></li>
							</ul>
							<!--/ End Tab Nav -->
							<!-- Tab Content -->
							<div class="tab-content">
								<div role="tabpanel" class="tab-pane fade in active" id="welcome">
									<p>WebHub Technology is a leader in Software Development and empowers IT individuals with competitive advantage. WebHub Technology dedicates itself to simplify the technology trends with its great R&D Division. WebHub Technology are an Indian Software Development Company. A rapidly growing software company with a team of experienced intellectuals working in various technologies. WebHub Technology is a high end full service IT solution Company based in India.</p>
									<div class="row">
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-check"></i>
												<h4>Software development </h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-support"></i>
												<h4>CRM Application</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-send"></i>
												<h4>Web development</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-rocket"></i>
												<h4>Outsourced product development</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane fade in" id="about">
									<div class="about">
										<p>At WebHub, we believe in a personal approach to every customer and project. Bringing in transparency, automation and dynamic environment, we choose development practices tailored to your specific business needs. Be it classical methodologies, such as RUP, MSF, CMMI, or modern approaches like Agile, we guarantee a timely delivery of the project within your budget.</p>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane fade in" id="information">
									<p>Founded in 2010, Webhub is a Ireland-headquartered provider of custom software development and IT consulting services with 150+ IT professionals located internationally.

For over 9 years we’ve been bringing custom and platform-based solutions to midsized and large companies in Healthcare, Telecom, Retail, Financial Services and other industries. With the background rooted in science, we build on our legacy knowledge and grow it dynamically in the areas of Collaboration, CRM, Data Analysis, VoIP and Information Security. As part of this journey.  At the same time, the major development center in Eastern Europe and the most recent one in South-Eastern Asia are our hubs of technological expertise in Process Automation, Mobility, Portals, Cloud and other disciplines. From here, our teams nurture and apply their competencies worldwide: while Northern America remains our principle market, our customers come from over 30 countries.</p>
									<div class="row">
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-check"></i>
												<h4>Website Designing and Development </h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-support"></i>
												<h4>E-Commmerece Application Development</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-send"></i>
												<h4>Apps Development </h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-rocket"></i>
												<h4>Fast Delivery</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
									</div>
								</div>
							</div>
							<!--/ End Tab Content -->
						</div>
						<!--/ End About Tab -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End About Us -->
		
		<!-- Our Skill -->
		<section id="our-skill" class="section">
			<div class="container">
				<div class="row"> 
					<div class="col-md-6 col-sm-12 col-xs-12 wow fadeIn">
						<!-- Info Main -->
						<div class="info-main">
							<div class="section-title left">
								<h2>Some <span>Info</span></h2>
							</div>
							<div class="some-info">
								<p>Morbi laoreet urna ante, quis luctus nisi sodales sit amet. Aliquam a enim in massa molestie mollis. Proin quis velit at nisl vulputate egestas non in arcu.Ut sodales eleifend sapien at fermentum.</p>
							</div>
							<ul class="info-list">
								<li><i class="fa fa-check"></i>consectetuer adipiscing elit, sed diam nonummy.</li>
								<li><i class="fa fa-check"></i>has been the industry'sstandar.</li>
								<li><i class="fa fa-check"></i>has been the industry'sstandar.</li>
								<li><i class="fa fa-check"></i>Pellentesque habitant morbi tristique senectus.</li>
							</ul>	
						</div>
						<!--/ End Info Main -->
					</div>				
					<div class="col-md-6 col-sm-12 col-xs-12">
						<!-- Skill Main -->
						<div class="skill-main">
							<div class="section-title left">
								<h2>Our <span>Skills</span></h2>
							</div>
							<!-- Single Skill -->
							<div class="single-skill">
								<div class="skill-info">
									<h4>Creative</h4>
								</div>
								<div class="progress">
									<div class="progress-bar" data-percent="80"><span>80%</span></div>
								</div>
							</div>	
							<!--/ End Single Skill -->
							<!-- Single Skill -->
							<div class="single-skill">
								<div class="skill-info">
									<h4>Web Design</h4>
								</div>
								<div class="progress">
									<div class="progress-bar" data-percent="90"><span>90%</span></div>
								</div>
							</div>	
							<!--/ End Single Skill -->
							<!-- Single Skill -->
							<div class="single-skill">
								<div class="skill-info">
									<h4>Marketing</h4>
								</div>
								<div class="progress">
									<div class="progress-bar" data-percent="70"><span>70%</span></div>
								</div>
							</div>	
							<!--/ End Single Skill -->
							<!-- Single Skill -->
							<div class="single-skill">
								<div class="skill-info">
									<h4>Success</h4>
								</div>
								<div class="progress">
									<div class="progress-bar" data-percent="60"><span>95%</span></div>
								</div>
							</div>	
							<!--/ End Single Skill -->
						</div>
						<!--/ End Skill Main -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Our Skill -->
		
		<!-- Why Choose Us -->
		<div id="why-choose" class="section">
			<div class="why-image">
				<div class="video"><a href="https://www.youtube.com/watch?v=wZWiRoktNWA" class="video-play mfp-iframe wow zoomIn"><i class="fa fa-play"></i></a></div>
				<!-- <img src="images/video.png" alt=""> -->
			</div>
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-12 col-xs-12 pull-right">
						<h2>Why Choose Us?</h2>
						<p>Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima.</p>
						<div class="row">
							<!-- Single Choose -->
							<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.4s">
								<div class="single-choose">
									<i class="fa fa-check"></i>
									<h4>100 Awards</h4>
								</div>
							</div>
							<!-- End Single Choose -->	
							<!-- Single Choose -->
							<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.6s">
								<div class="single-choose">
									<i class="fa fa-facebook"></i>
									<h4>500K Fans</h4>
								</div>
							</div>
							<!-- End Single Choose -->	
							<!-- Single Choose -->
							<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.8s">
								<div class="single-choose">
									<i class="fa fa-youtube"></i>
									<h4>100K Subscriber</h4>
								</div>
							</div>
							<!-- End Single Choose -->	
							<!-- Single Choose -->
							<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="1s">
								<div class="single-choose">
									<i class="fa fa-support"></i>
									<h4>24/7 Support</h4>
								</div>
							</div>
							<!-- End Single Choose -->	
						</div>
					</div>					
				</div>
			</div>
		</div>	
		<!--/ End Why Choose Us -->
		
		<!-- Start Team -->
		<section id="team" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>Lovely <span>Team</span></h2>
							<p>Coordinates for abs potioning the closest positioned parent box of the positioned abs qoning the closes for abs potioning the closest positioned parent.</p>
						</div>
					</div>
				</div>
				<div class="row">	
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.4s">
						<!-- Single Team -->
						<div class="single-team">
							<div class="team-head">
								<img src="images/team/team1.jpg" alt=""/>							</div>
							<div class="team-info">
								<div class="name">
									<h4>Trans L<span>Creative Director</span></h4>
								</div>
								<p>Pellentesque habitant morbi tristique senectus et netus et malesuada</p>
								<ul class="team-social">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-instagram"></i></a></li>
								</ul>
							</div>
						</div>
						<!--/ End Single Team -->
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.6s">	
						<!-- Single Team -->
						<div class="single-team">
							<div class="team-head">
								<img src="images/team/team2.jpg" alt=""/>							</div>
							<div class="team-info">
								<div class="name">
									<h4>Augsed Lamp<span>Web Developer</span></h4>
								</div>
								<p>Pellentesque habitant morbi tristique senectus et netus et malesuada</p>
								<ul class="team-social">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-instagram"></i></a></li>
								</ul>
							</div>
						</div>
						<!--/ End Single Team -->
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.8s">
						<!-- Single Team -->
						<div class="single-team active">
							<div class="team-head">
								<img src="images/team/team3.jpg" alt=""/>							</div>
							<div class="team-info">
								<div class="name">
									<h4>Fronas Kie<span>Server Administor</span></h4>
								</div>
								<p>Pellentesque habitant morbi tristique senectus et netus et malesuada</p>
								<ul class="team-social">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-instagram"></i></a></li>
								</ul>
							</div>
						</div>
						<!--/ End Single Team -->
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="1s">	
						<!-- Single Team -->
						<div class="single-team">
							<div class="team-head">
								<img src="images/team/team4.jpg" alt=""/>							</div>
							<div class="team-info">
								<div class="name">
									<h4>Lifae Hoadas<span>UI/UX Design</span></h4>
								</div>
								<p>Pellentesque habitant morbi tristique senectus et netus et malesuada</p>
								<ul class="team-social">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-instagram"></i></a></li>
								</ul>
							</div>
						</div>
						<!--/ End Single Team -->
					</div>
				</div>
            </div>
		</section>	 
		<!--/ End Team -->		
		
		<!-- Start Testimonials -->
		<section id="testimonial" class="section wow fadeIn">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>Our <span>Testimonials</span></h2>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="testimonial-carousel">	
							<!-- Single Testimonial -->
							<div class="single-testimonial">
								<div class="testimonial-content">
									<p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, </p>
								</div>
								<div class="testimonial-info">
									<div class="img">
										<span class="arrow"></span>
										<img src="images/testimonial1.jpg" class="img-circle" alt="">									</div>
									<h6>Trom<span>Founder Hoadas</span></h6>
								</div>			
							</div>
							<!--/ End Single Testimonial -->
							<!-- Single Testimonial -->
							<div class="single-testimonial">
								<div class="testimonial-content">
									<p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, </p>
								</div>
								<div class="testimonial-info">
									<div class="img">
										<span class="arrow"></span>
										<img src="images/testimonial2.jpg" class="img-circle" alt="">									</div>
									<h6>Trom<span>Founder Hoadas</span></h6>
								</div>			
							</div>
							<!--/ End Single Testimonial -->
							<!-- Single Testimonial -->
							<div class="single-testimonial">
								<div class="testimonial-content">
									<p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, </p>
								</div>
								<div class="testimonial-info">
									<div class="img">
										<span class="arrow"></span>
										<img src="images/testimonial3.jpg" class="img-circle" alt="">									</div>
									<h6>Trom<span>Founder Hoadas</span></h6>
								</div>			
							</div>
							<!--/ End Single Testimonial -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Testimonial -->

		<!-- Start Portfolio -->
		<section id="portfolio" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>Our <span>Portfolio</span></h2>
							<p>Coordinates for abs potioning the closest positioned parent box of the positioned abs qoning the closes for abs potioning the closest positioned parent.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="portfolio-carousel">
							<!-- Single Portfolio -->
							<div class="portfolio-single">
								<a href="images/portfolio/1.jpg" class="zoom">
									<div class="portfolio-head">
										<img src="images/portfolio/1.jpg" alt=""/>
										<i class="fa fa-search"></i>									</div>
								</a>
								<div class="text">
									<h4><a href="portfolio-single.php">Portfolio 1</a></h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam interdum.</p>
								</div>
							</div>
							<!--/ End Portfolio -->
							<!-- Single Portfolio -->
							<div class="portfolio-single">
								<a href="images/portfolio/2.jpg" class="zoom">
									<div class="portfolio-head">
										<img src="images/portfolio/2.jpg" alt=""/>
										<i class="fa fa-search"></i>									</div>
								</a>
								<div class="text">
									<h4><a href="portfolio-single.php">Portfolio 2</a></h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam interdum.</p>
								</div>
							</div>
							<!--/ End Portfolio -->
							<!-- Single Portfolio -->
							<div class="portfolio-single">
								<a href="images/portfolio/3.jpg" class="zoom">
									<div class="portfolio-head">
										<img src="images/portfolio/3.jpg" alt=""/>
										<i class="fa fa-search"></i>									</div>
								</a>
								<div class="text">
									<h4><a href="portfolio-single.php">Portfolio 3</a></h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam interdum.</p>
								</div>
							</div>
							<!--/ End Portfolio -->
							<!-- Single Portfolio -->
							<div class="portfolio-single">
								<a href="images/portfolio/4.jpg" class="zoom">
									<div class="portfolio-head">
										<img src="images/portfolio/4.jpg" alt=""/>
										<i class="fa fa-search"></i>									</div>
								</a>
								<div class="text">
									<h4><a href="portfolio-single.php">Portfolio 4</a></h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam interdum.</p>
								</div>
							</div>
							<!--/ End Portfolio -->
							<!-- Single Portfolio -->
							<div class="portfolio-single">
								<a href="images/portfolio/5.jpg" class="zoom">
									<div class="portfolio-head">
										<img src="images/portfolio/5.jpg" alt=""/>
										<i class="fa fa-search"></i>									</div>
								</a>
								<div class="text">
									<h4><a href="portfolio-single.php">Portfolio 5</a></h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam interdum.</p>
								</div>
							</div>
							<!--/ End Portfolio -->
							<!-- Single Portfolio -->
							<div class="portfolio-single">
								<a href="images/portfolio/6.jpg" class="zoom">
									<div class="portfolio-head">
										<img src="images/portfolio/6.jpg" alt=""/>
										<i class="fa fa-search"></i>									</div>
								</a>
								<div class="text">
									<h4><a href="portfolio-single.php">Portfolio 6</a></h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam interdum.</p>
								</div>
							</div>
							<!--/ End Portfolio -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Portfolio -->
		
		<!-- Start Statics -->
		<section id="statics" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-12 col-xs-12">
						<div class="row">
							<div class="statics">	
								<div class="col-md-12 col-sm-12 col-xs-12">
									<h2>World Domination!</h2>
									<p>Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima.</p>
								</div>
								<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.4s">
									<!-- Static Single -->
									<div class="static-single">
										<div class="number"><span class="counter">1300</span></div>
										<p>Project Complete</p>
									</div>
								</div>
								<!-- End Single -->	
								<!-- Static Single -->
								<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.6s">
									<div class="static-single">
										<div class="number"><span class="counter">123300</span></div>
										<p>Support Tiket</p>
									</div>
								</div>
								<!-- End Single -->	
								<!-- Static Single -->
								<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.8s">
									<div class="static-single">
										<div class="number"><span class="counter">55300</span></div>
										<p>Global Clients</p>
									</div>
								</div>
								<!-- End Single -->	
								<!-- Static Single -->
								<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="1s">
									<div class="static-single">
										<div class="number"><span class="counter">40.99</span><span class="percent">%</span></div>
										<p>World Domination</p>
									</div>
								</div>
								<!-- End Single -->	
							</div>
						</div>
					</div>					
				</div>
			</div>
			<div class="static-image wow fadeIn"></div>
		</section>	
		<!--/ End Statics -->
		
		<!-- Start blog -->
		<section id="blog" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12  wow fadeIn">
						<div class="section-title center">
							<h2>Our <span>Blog</span></h2>
							<p>Coordinates for abs potioning the closest positioned parent box of the positioned abs qoning the closes for abs potioning the closest positioned parent.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="blog">
							<div class="col-md-4 col-sm-6 col-xs-12">
								<!-- Single blog -->
								<div class="single-blog">
									<div class="blog-head">
										<img src="images/blog/1.jpg" alt="#">
										<a href="#" class="link"><i class="fa fa-link"></i></a>									</div>
									<div class="blog-content">
										<h2><a href="#">We create one page business website</a></h2>
										<div class="meta">
											<span><i class="fa fa-user"></i>admin</span>
											<span><i class="fa fa-calendar"></i>18 June</span>
											<span><i class="fa fa-comments"></i>5 Comments</span>
										</div>
										<p>Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis.</p>
										<a href="#" class="btn">Read More<i class="fa fa-angle-double-right"></i></a>
									</div>
								</div>	
								<!--/ End Single blog -->
							</div>
							<div class="col-md-4 col-sm-6 col-xs-12">
								<!-- Single blog -->
								<div class="single-blog">
									<div class="blog-head">
										<img src="images/blog/2.jpg" alt="#">
										<a href="#" class="link"><i class="fa fa-link"></i></a>									</div>
									<div class="blog-content">
										<h2><a href="#">Super,Clean HTML5 Templates ever you seen!</a></h2>
										<div class="meta">
											<span><i class="fa fa-user"></i>admin</span>
											<span><i class="fa fa-calendar"></i>29 June</span>
											<span><i class="fa fa-comments"></i>5 Comments</span>
										</div>
										<p>Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis.</p>
										<a href="#" class="btn">Read More<i class="fa fa-angle-double-right"></i></a>
									</div>
								</div>	
								<!--/ End Single blog -->
							</div>
							<div class="col-md-4 col-sm-6 col-xs-12">
								<!-- Single blog -->
								<div class="single-blog">
									<div class="blog-head">
										<img src="images/blog/3.jpg" alt="#">
										<a href="#" class="link"><i class="fa fa-link"></i></a>									</div>
									<div class="blog-content">
										<h2><a href="#">Responsive Retina Ready Html template</a></h2>
										<div class="meta">
											<span><i class="fa fa-user"></i>admin</span>
											<span><i class="fa fa-calendar"></i>19 June</span>
											<span><i class="fa fa-comments"></i>5 Comments</span>
										</div>
										<p>Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis.</p>
										<a href="#p" class="btn">Read More<i class="fa fa-angle-double-right"></i></a>
									</div>
								</div>	
								<!--/ End Single blog -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End blog -->

		<!-- Contact Us -->
		<section id="contact" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>Contact <span>US</span></h2>
							<p>Do you have any questions, suggestions, feedback or just want to contact us? Or perhaps you just want to say hello? Feel free to send us a message! </p>
						</div>
					</div>
				</div>
				<!-- Google Map -->
				<div class="row">
					<!-- Contact Form -->
					<div class="col-md-5 col-sm-5 col-xs-12">
						<form class="form" method="post" action="mail/mail.php">
							<div class="form-group">
								<input type="text" name="name" placeholder="Name" required="required">
                            </div>
							<div class="form-group">
								<input type="email" name="email" placeholder="Email" required="required">
                            </div>
							<div class="form-group">
								<input type="text" name="subject" placeholder="Subject" required="required">
                            </div>
							<div class="form-group">
								<textarea name="message" rows="6" placeholder="Message" ></textarea>
                            </div>
							<div class="form-group">	
								<button type="submit" class="button primary"><i class="fa fa-send"></i>Submit</button>
								<button type="reset" class="button primary"><i class="fa fa-send"></i>Reset</button>
                            </div>
						</form>
					</div>
					<!--/ End Contact Form -->
				</div>
			</div>
			<div class="gmap">
				<div class="map"></div>
			</div>
		</section>
		<!--/ End Clients Us -->
		
		<!-- Location -->
		<section id="location" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>Our <span>Location</span></h2>
							<p>Coordinates for abs potioning the closest positioned parent box of the positioned abs qoning the closes for abs potioning the closest positioned parent.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeIn" data-wow-delay="0.4s">
						<!-- Single Address -->
						<div class="single-address">
							<i class="fa fa-phone"></i>
							<h4>Our Phone</h4>
							<p>+91 9049265435, +91 9579670950</p>
						</div>
						<!--/ End Single Address -->
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeIn" data-wow-delay="0.6s">
						<!-- Single Address -->
						<div class="single-address active">
							<i class="fa fa-phone"></i>
							<h4>Office Location</h4>
							<p>5th floor,  Above Jijamata bank, Karvenagar, Pune.</p>
						</div>
						<!--/ End Single Address -->
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeIn" data-wow-delay="0.8s">
						<!-- Single Address -->
						<div class="single-address">
							<i class="fa fa-phone"></i>
							<h4>Corporate Email</h4>
							<p>info@webhub.co.in, support@webhub.co.in</p>
						</div>
						<!--/ End Single Address -->
					</div>

				</div>
			</div>
		</section>
		<!--/ End Location -->
		
		<!-- Newslatter -->
		<div id="newslatter" class="wow fadeIn">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-6 col-xs-12">
						<h2>Signup Newslatter</h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry'sstandard dummy text</p>
					</div>
					<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="newslatter">
							<form>
								<input type="email" placeholder="type your email">
								<button type="submit" class="button primary"><i class="fa fa-paper-plane"></i></button>
							</form>	
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Newslatter -->
		
		<!-- Start Clients -->
		<div id="clients" class="section wow fadeIn">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="clients-carousel">
							<!-- Single Clients -->
							<div class="single-client">
								<img src="images/client1.png" alt="" class="img-responsive">
							</div>
							<!--/ Single Clients -->
							<!-- Single Clients -->
							<div class="single-client">
								<img src="images/client2.png" alt="" class="img-responsive">
							</div>
							<!--/ Single Clients -->
							<!-- Single Clients -->
							<div class="single-client">
								<img src="images/client3.png" alt="" class="img-responsive">
							</div>
							<!--/ Single Clients -->
							<!-- Single Clients -->
							<div class="single-client">
								<img src="images/client4.png" alt="" class="img-responsive">
							</div>
							<!--/ Single Clients -->
							<!-- Single Clients -->
							<div class="single-client">
								<img src="images/client5.png" alt="" class="img-responsive">
							</div>
							<!--/ Single Clients -->
							<!-- Single Clients -->
							<div class="single-client">
								<img src="images/client6.png" alt="" class="img-responsive">
							</div>		
							<!--/ Single Clients -->
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Clients -->		
	
		<!-- Start Footer -->
		<footer id="footer" class="wow fadeIn">
			<!-- Footer Top -->
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12 ">
							<!-- Logo -->
							<div class="logo">
								<a href="index.php"><span>WebHub </span>Technology</a>
							</div>	
							<!--/ End Logo -->
							<!-- Social -->
							<ul class="social">
								<li class="active"><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
							</ul>	
							<!--/ End Social -->
							<!-- Menu -->
							<ul class="nav">
								<li><a href="index.php">Home</a></li>
								<li><a href="portfolio.php">Portfolio</a></li>
								<li><a href="blog.php">Latest Blog</a></li>
								<li><a href="#">Contact</a></li>
							</ul>		
							<!--/ End Menu -->
						</div>
					</div>
				</div>
			</div>
			<!--/ End Footer Top -->
			
			<!-- Copyright -->
			<div class="copyright">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<div class="text">
								<p>&copy; Copyright 2018<span><i class="fa fa-heart"></i></span><a href="https://webhub.co.in.com/" target="_blank">WebHub Technology</a> </p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ End Copyright -->
		</footer>
		<!--/ End Footer -->

		<!-- Jquery JS -->
		<script type="text/javascript" src="js/jquery.min.js"></script>
		
		<!-- Colors JS -->
		<script type="text/javascript" src="js/colors.js"></script>
		
		<!-- Google Map JS -->
		<script  type="text/javascript" src="js/gmap.js"></script>
		
		<!-- Modernizr JS -->
		<script type="text/javascript"  src="js/modernizr.min.js"></script>
	
		<!-- Appear JS-->
		<script  type="text/javascript" src="js/jquery.appear.js"></script>

		<!-- Animate JS -->
    	<script  type="text/javascript" src="js/wow.min.js"></script>
		
		<!-- Onepage Nav JS -->
    	<script  type="text/javascript" src="js/jquery.nav.js"></script>
		
		<!-- Yt Player -->
		<script  type="text/javascript" src="js/ytplayer.min.js"></script>
	
		<!-- Popup JS -->
		<script type="text/javascript"  src="js/jquery.magnific-popup.min.js"></script>

		<!-- Typed JS -->
		<script  type="text/javascript" src="js/typed.min.js"></script>
		
		<!-- Scroll Up JS -->
		<script  type="text/javascript" src="js/jquery.scrollUp.min.js"></script>
		
		<!-- Slick Nav JS -->
		<script  type="text/javascript" src="js/jquery.slicknav.min.js"></script>
		
		<!-- Counterup JS -->
		<script  type="text/javascript" src="js/waypoints.min.js"></script>
		<script  type="text/javascript" src="js/jquery.counterup.min.js"></script>
		
		<!-- Owl Carousel JS -->
		<script  type="text/javascript" src="js/owl.carousel.min.js"></script>
		
		<!-- Bootstrap JS -->
		<script  type="text/javascript" src="js/bootstrap.min.js"></script>
		
		<!-- Main JS -->
		<script type="text/javascript"  src="js/main.js"></script>
    </body>
</html>